If you are reading this it means that you have likely read my disseration! If so, thanks :)

This is the majority of the code that I contributed, however, I have the majority of the 
files from the initial frameworks - e.g. from CycleGAN and UVCGAN.

These frameworks can be found at the following githubs:

https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/tree/master
https://github.com/LS4GAN/uvcgan

Also, I frequently used DepthAnything and SeaThru, which can be located at the following links:

https://github.com/LiheYoung/Depth-Anything
https://github.com/hainh/sea-thru

To reproduce my results, the pre-trained models can be loaded using these frameworks, using the parameters discussed in the report.

For any further questions, please email me: rp21039@bristol.ac.uk

Enjoy!