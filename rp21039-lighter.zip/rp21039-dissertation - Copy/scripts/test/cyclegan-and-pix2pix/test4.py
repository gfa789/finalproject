"""General-purpose test script for image-to-image translation.

Once you have trained your model with train.py, you can use this script to test the model.
It will load a saved model from '--checkpoints_dir' and save the results to '--results_dir'.

It first creates model and dataset given the option. It will hard-code some parameters.
It then runs inference for '--num_test' images and save results to an HTML file.

Example (You need to train models first or download pre-trained models from our website):
    Test a CycleGAN model (both sides):
        python test.py --dataroot ./datasets/maps --name maps_cyclegan --model cycle_gan

    Test a CycleGAN model (one side only):
        python test.py --dataroot datasets/horse2zebra/testA --name horse2zebra_pretrained --model test --no_dropout

    The option '--model test' is used for generating CycleGAN results only for one side.
    This option will automatically set '--dataset_mode single', which only loads the images from one set.
    On the contrary, using '--model cycle_gan' requires loading and generating results in both directions,
    which is sometimes unnecessary. The results will be saved at ./results/.
    Use '--results_dir <directory_path_to_save_result>' to specify the results directory.

    Test a pix2pix model:
        python test.py --dataroot ./datasets/facades --name facades_pix2pix --model pix2pix --direction BtoA

See options/base_options.py and options/test_options.py for more test options.
See training and test tips at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/tips.md
See frequently asked questions at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/qa.md
"""
import os
import cv2
import imageio
import numpy as np
import copy

import torch
from options.test_options import TestOptions
from data import create_dataset
from models import create_model
from util.visualizer import save_images
from util import html
from util.util import tensor2im
from data.george_dataset import load_tiff_image
from PIL import Image, ImageDraw, ImageFont
from data.base_dataset import get_transform
import torch.nn.functional as F
from tqdm.auto import tqdm

import cv2
from depth_anything.dpt import DepthAnything
from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

import torch.nn.functional as F
from torchvision.transforms import Compose

try:
    import wandb
except ImportError:
    print('Warning: wandb package cannot be found. The option "--use_wandb" will result in error.')


if __name__ == '__main__':
    opt = TestOptions().parse()  # get test options
    # hard-code some parameters for test
    opt.num_threads = 0   # test code only supports num_threads = 0
    opt.batch_size = 1    # test code only supports batch_size = 1
    opt.serial_batches = True  # disable data shuffling; comment this line if results on randomly chosen images are needed.
    opt.no_flip = True    # no flip; comment this line if results on flipped images are needed.
    opt.display_id = -1   # no visdom display; the test code saves the results to a HTML file.
    models = []
    dataset = create_dataset(opt)  # create a dataset given opt.dataset_mode and other options
    model = create_model(opt)      # create a model given opt.model and other options
    model.setup(opt)
    models.append((model, opt))
    # FOR CALLING OF python train.py --dataroot CG --model cycle_gan --name NAMEOFCG3->3


    DEVICE = 'cpu'

    
    if opt.eval:
        for m in models:
            m.eval()

    def randCrop(h, w):
        min_res = min(w-1, h-1)
        crop_size = min(min_res, 800)
        rand_width = np.random.randint(0, w-crop_size+1)
        rand_height = np.random.randint(0, h-crop_size+1)
        # im = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
        return rand_height,rand_width, crop_size
    model_names = ["CycleGAN33"
                #    , "CycleGAN153", 
                #    "P2P33", "P2P44", 
                #    "CycleGAN44"
                ]
    model_name = ["pix2pix33"]
    if not os.path.exists(f"results/{model_name}/"): os.mkdir(f"results/{model_name}/")
    # font = ImageFont.truetype("calibri.ttf", 20)
    indir = "../uvcgan/data/example_dataset/testA/"
    files = os.listdir(indir)
    files = [indir+x for x in files]
    for i, file in tqdm(enumerate(files), total = len(files)):
        outdir = file.replace(indir, f"results/{model_name}/")
        # print(outdir)
        if i == 200: break
        frame = cv2.imread(file)
        # frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_height, frame_width, _ = frame.shape
        rand_height, rand_width, crop_size = randCrop(frame_height, frame_width)
        frame = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
        frame = np.array(Image.fromarray(frame).resize((256,256)))
        
        # left_bar = Image.fromarray(side_bar)
        # draw = ImageDraw.Draw(left_bar)
        # x, y = 50, 15
        # draw.text((x, y), "ORIGINAL", font=font, fill="white", anchor="ms")
        # left_bar = left_bar.rotate(90, expand =1)
        # print(np.array(left_bar).shape)
        # processed = np.hstack([np.array(left_bar), frame])
        # rows = []
        # rows.append(processed)
        for (m, o), name in zip(models,model_names):
            # print(o.input_nc)
            # print(o)
            # d_trans = get_transform(o, grayscale=True)
            transform = get_transform(o, grayscale=(o.input_nc == 1))
            
            image = Image.fromarray(frame.astype('uint8'), 'RGB')
            tens = transform(image)
            tens = tens.unsqueeze(0)
            # print(tens.size())

            img = m.processAtoB(tens)

            # print(img.size())
            # imgtodepth = img.
            # image_numpy = img[0].data.float().numpy()
            image_numpy = tensor2im(img)
        
        cv2.imwrite(outdir.replace(".png", "_A.png"),frame)
        cv2.imwrite(outdir.replace(".png", "_B.png"),image_numpy)
