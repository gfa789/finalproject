"""General-purpose test script for image-to-image translation.

Once you have trained your model with train.py, you can use this script to test the model.
It will load a saved model from '--checkpoints_dir' and save the results to '--results_dir'.

It first creates model and dataset given the option. It will hard-code some parameters.
It then runs inference for '--num_test' images and save results to an HTML file.

Example (You need to train models first or download pre-trained models from our website):
    Test a CycleGAN model (both sides):
        python test.py --dataroot ./datasets/maps --name maps_cyclegan --model cycle_gan

    Test a CycleGAN model (one side only):
        python test.py --dataroot datasets/horse2zebra/testA --name horse2zebra_pretrained --model test --no_dropout

    The option '--model test' is used for generating CycleGAN results only for one side.
    This option will automatically set '--dataset_mode single', which only loads the images from one set.
    On the contrary, using '--model cycle_gan' requires loading and generating results in both directions,
    which is sometimes unnecessary. The results will be saved at ./results/.
    Use '--results_dir <directory_path_to_save_result>' to specify the results directory.

    Test a pix2pix model:
        python test.py --dataroot ./datasets/facades --name facades_pix2pix --model pix2pix --direction BtoA

See options/base_options.py and options/test_options.py for more test options.
See training and test tips at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/tips.md
See frequently asked questions at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/qa.md
"""
import os
import cv2
import imageio
import numpy as np
import copy

import torch
from options.test_options import TestOptions
from data import create_dataset
from models import create_model
from util.visualizer import save_images
from util import html
from util.util import tensor2im
from data.george_dataset import load_tiff_image
from PIL import Image, ImageDraw, ImageFont
from data.base_dataset import get_transform
import torch.nn.functional as F
from tqdm.auto import tqdm

import cv2
from depth_anything.dpt import DepthAnything
from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

import torch.nn.functional as F
from torchvision.transforms import Compose

try:
    import wandb
except ImportError:
    print('Warning: wandb package cannot be found. The option "--use_wandb" will result in error.')


if __name__ == '__main__':
    opt = TestOptions().parse()  # get test options
    # hard-code some parameters for test
    opt.num_threads = 0   # test code only supports num_threads = 0
    opt.batch_size = 1    # test code only supports batch_size = 1
    opt.serial_batches = True  # disable data shuffling; comment this line if results on randomly chosen images are needed.
    opt.no_flip = True    # no flip; comment this line if results on flipped images are needed.
    opt.display_id = -1   # no visdom display; the test code saves the results to a HTML file.
    models = []
    dataset = create_dataset(opt)  # create a dataset given opt.dataset_mode and other options
    model = create_model(opt)      # create a model given opt.model and other options
    model.setup(opt)
    models.append((model, opt))
    # print(opt)

    #OPT4 FOR PIX2PIX 4 -> 4 
    # opt_4 = copy.copy(opt)
    # # opt_4.model = "pix2pix"
    # opt_4.dataset_mode = "depth"
    # opt_4.dataroot = "synDepDepth"
    # opt_4.name = "P2P44"
    # opt_4.input_nc = 4
    # opt_4.output_nc = 4
    # # opt_4.net_G = "unet_256"
    # # opt_4.norm = "batch"
    # # opt_4.no_dropout = False
    # model4 = create_model(opt_4)
    # model4.setup(opt_4)
    # models.append((model4,opt_4))

    DEVICE = 'cpu'
    
    # initialize logger
    # if opt.use_wandb:
    #     wandb_run = wandb.init(project=opt.wandb_project_name, name=opt.name, config=opt) if not wandb.run else wandb.run
    #     wandb_run._label(repo='CycleGAN-and-pix2pix')

    # create a website
    # web_dir = os.path.join(opt.results_dir, opt.name, '{}_{}'.format(opt.phase, opt.epoch))  # define the website directory
    # if opt.load_iter > 0:  # load_iter is 0 by default
    #     web_dir = '{:s}_iter{:d}'.format(web_dir, opt.load_iter)
    # print('creating web directory', web_dir)
    # webpage = html.HTML(web_dir, 'Experiment = %s, Phase = %s, Epoch = %s' % (opt.name, opt.phase, opt.epoch))
    # test with eval mode. This only affects layers like batchnorm and dropout.
    # For [pix2pix]: we use batchnorm and dropout in the original pix2pix. You can experiment it with and without eval() mode.
    # For [CycleGAN]: It should not affect CycleGAN as CycleGAN uses instancenorm without dropout.
    if opt.eval:
        for m in models:
            m.eval()
    def randCrop(h, w):
        min_res = min(w-1, h-1)
        crop_size = min(min_res, 800)
        rand_width = np.random.randint(0, w-crop_size+1)
        rand_height = np.random.randint(0, h-crop_size+1)
        # im = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
        return rand_height,rand_width, crop_size
    video_name = "canyon1raw"
    inputdir = f"../SyreaNet/synthesize/vids/{video_name}.mp4"
    # reader = imageio.get_reader(inputdir)
    cap = cv2.VideoCapture(inputdir)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
  
    rand_height, rand_width, crop_size = randCrop(frame_height, frame_width)
    # crop_size = 256
    # writer = imageio.get_writer(f'p2p_vid_{opt.epoch}.mp4', fps=30)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(f'vids/cyclegan_vid_{opt.epoch}_{video_name}.mp4', fourcc, 30.0, (256, 256))
    if not os.path.exists('vids/frames'): os.mkdir('vids/frames')

    # print(frames)
    # params = {'crop_pos': (0,0)}
    # black_square = np.zeros((256,256,3), dtype=np.uint8)
    h, w = 256, 256
    # side_bar = np.zeros((32, 256, 3), dtype=np.uint8)
    model_names = [
        # "CycleGAN33", "CycleGAN153", 
                #    "P2P33", "P2P44", 
        "beta33"
                #    "CycleGAN44"
                    ]

    # font = ImageFont.truetype("calibri.ttf", 20)
    i = 0
    while True:
        ret, frame = cap.read()
        if i % 5 == 0: print(i/100)
        if i == 200: break
        # if i == 200: break
        if ret:
            frame = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
            frame = np.array(Image.fromarray(frame).resize((256,256)))
            # left_bar = Image.fromarray(side_bar)
            # draw = ImageDraw.Draw(left_bar)
            # x, y = 50, 15
            # draw.text((x, y), "ORIGINAL", font=font, fill="white", anchor="ms")
            # left_bar = left_bar.rotate(90, expand =1)
            # print(np.array(left_bar).shape, frame.shape)
            # processed = np.hstack([np.array(left_bar), frame])
            # rows = []
            # rows.append(processed)
            for (m, o), name in zip(models,model_names):
                # print(o.input_nc)
                # print(o)
                # d_trans = get_transform(o, grayscale=True)
                transform = get_transform(o, grayscale=(o.input_nc == 1))
                
                image = Image.fromarray(frame.astype('uint8'), 'RGB')
                tens = transform(image)
                tens = tens.unsqueeze(0)
    
                img = m.processAtoB(tens)

                # print(img.size())
                # imgtodepth = img.
                # image_numpy = img[0].data.float().numpy()
                image_numpy = tensor2im(img)
                # print(img.shape)
                
                # model_label = Image.fromarray(side_bar)
                # drawer = ImageDraw.Draw(model_label)
                # drawer.text((x, y), name, font=font, fill="white", anchor="ms")
                # model_label = model_label.rotate(90, expand = 1)
                # model_label = np.array(model_label)
                # row = np.hstack([model_label, image_numpy])
                # rows.append(row)

            # bottom_bar = np.zeros((32,256,3), dtype=np.uint8)
            # bottom_bars = []
            # bottom_bars.append(np.zeros((32,32,3), dtype=np.uint8))
            # bottom_labels = [f"Output - {opt.epoch} epochs"]
            # x, y = 20, 10
            # for label in bottom_labels:
                # model_label = Image.fromarray(bottom_bar)
                # draw = ImageDraw.Draw(model_label)
                # draw.text((x, y), label, font=font, fill="white", anchor="ms")
                # bottom_bars.append(np.array(model_label))
            # print(rows)
            # print(bottom_bars)
            # bartoadd = np.hstack(bottom_bars)
            # rows.append(np.array(bartoadd))
            # print([x.shape for x in rows])
            # output = np.vstack(rows)
            # print(output.shape)
            
            cv2.imwrite(f'vids/frames/{video_name}_{i}_A.png', frame)
            cv2.imwrite(f'vids/frames/{video_name}_{i}_B.png', image_numpy)
            writer.write(image_numpy)
            i += 1
    writer.release()
