import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import os 
# import imageio
import cv2


syn_dir = "synDep/train/"
synthetic_files = [syn_dir + x for x in os.listdir(syn_dir)]
synthetic_images = [cv2.imread(x)[:256, :256, :256] for x  in synthetic_files if x.endswith(('.png','.jpg','.jpeg'))]
syn_len = len(synthetic_images)
synthetic_images = np.array(synthetic_images)
print(synthetic_images.shape)

real_dir = "CG/trainA/"
real_files = [real_dir + x for x in os.listdir(real_dir) ]
real_images = [cv2.imread(x) for x in real_files if x.endswith(('.png','.jpg','.jpeg'))]
real_len = len(real_images)
real_images = np.array(real_images)
print(real_images.shape)

if syn_len > real_len:
    synthetic_images = synthetic_images[:real_len]
else:
    real_images = real_images[:syn_len]

synthetic_flat = synthetic_images.reshape((synthetic_images.shape[0], -1))
real_flat = real_images.reshape((real_images.shape[0], -1))

X_combined = np.vstack((synthetic_flat, real_flat))
y_labels = np.array([0]*len(synthetic_flat) + [1]*len(real_flat))

tsne = TSNE(n_components=2, perplexity=30, random_state=42)
X_reduced = tsne.fit_transform(X_combined)

plt.figure(figsize=(10, 6))
plt.scatter(X_reduced[y_labels == 0, 0], X_reduced[y_labels == 0, 1], c='blue', label='Synthetic', alpha=0.5)
plt.scatter(X_reduced[y_labels == 1, 0], X_reduced[y_labels == 1, 1], c='red', label='Real', alpha=0.5)
plt.legend()
plt.title('t-SNE visualization of Synthetic vs. Real Data')
plt.xlabel('t-SNE feature 1')
plt.ylabel('t-SNE feature 2')
plt.show()