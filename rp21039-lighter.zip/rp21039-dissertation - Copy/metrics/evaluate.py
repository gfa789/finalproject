"""General-purpose test script for image-to-image translation.

Once you have trained your model with train.py, you can use this script to test the model.
It will load a saved model from '--checkpoints_dir' and save the results to '--results_dir'.

It first creates model and dataset given the option. It will hard-code some parameters.
It then runs inference for '--num_test' images and save results to an HTML file.

Example (You need to train models first or download pre-trained models from our website):
    Test a CycleGAN model (both sides):
        python test.py --dataroot ./datasets/maps --name maps_cyclegan --model cycle_gan

    Test a CycleGAN model (one side only):
        python test.py --dataroot datasets/horse2zebra/testA --name horse2zebra_pretrained --model test --no_dropout

    The option '--model test' is used for generating CycleGAN results only for one side.
    This option will automatically set '--dataset_mode single', which only loads the images from one set.
    On the contrary, using '--model cycle_gan' requires loading and generating results in both directions,
    which is sometimes unnecessary. The results will be saved at ./results/.
    Use '--results_dir <directory_path_to_save_result>' to specify the results directory.

    Test a pix2pix model:
        python test.py --dataroot ./datasets/facades --name facades_pix2pix --model pix2pix --direction BtoA

See options/base_options.py and options/test_options.py for more test options.
See training and test tips at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/tips.md
See frequently asked questions at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/qa.md
"""
import os
import cv2
import imageio
import numpy as np
import copy

import torch
from options.test_options import TestOptions
from data import create_dataset
from models import create_model
from util.visualizer import save_images
from util import html
from util.util import tensor2im
from data.george_dataset import load_tiff_image
from PIL import Image, ImageDraw, ImageFont
from data.base_dataset import get_transform
import torch.nn.functional as F
from tqdm.auto import tqdm

import cv2
from depth_anything.dpt import DepthAnything
from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

import torch.nn.functional as F
from torchvision.transforms import Compose

try:
    import wandb
except ImportError:
    print('Warning: wandb package cannot be found. The option "--use_wandb" will result in error.')


if __name__ == '__main__':
    opt = TestOptions().parse()  # get test options
    # hard-code some parameters for test
    opt.num_threads = 0   # test code only supports num_threads = 0
    opt.batch_size = 1    # test code only supports batch_size = 1
    opt.serial_batches = True  # disable data shuffling; comment this line if results on randomly chosen images are needed.
    opt.no_flip = True    # no flip; comment this line if results on flipped images are needed.
    opt.display_id = -1 
    dataset = create_dataset(opt)  # create a dataset given opt.dataset_mode and other options
    model = create_model(opt)      # create a model given opt.model and other options
    model.setup(opt)
    # print(opt)

    #OPT4 FOR PIX2PIX 4 -> 4 
    # opt_4 = copy.copy(opt)
    # # opt_4.model = "pix2pix"
    # opt_4.dataset_mode = "depth"
    # opt_4.dataroot = "synDepDepth"
    # opt_4.name = "P2P44"
    # opt_4.input_nc = 4
    # opt_4.output_nc = 4
    # # opt_4.net_G = "unet_256"
    # # opt_4.norm = "batch"
    # # opt_4.no_dropout = False
    # model4 = create_model(opt_4)
    # model4.setup(opt_4)
    # models.append((model4,opt_4))

    if opt.eval:
        model.eval()
    
    inputdir = f"../SyreaNet/synthesize/evaluate/SAUD/Benchmark/Raw/group_"
    groups = [inputdir + str(x) for x in range(1,6)]

    def randCrop(h, w):
        min_res = min(w-1, h-1)
        crop_size = min(min_res, 800)
        rand_width = np.random.randint(0, w-crop_size+1)
        rand_height = np.random.randint(0, h-crop_size+1)
        # im = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
        return rand_height,rand_width, crop_size

    def cropImage(im, sx, sy, cs):
        return im[sy:sy+cs, sx:sx+cs]


    for i, g in enumerate(tqdm(groups, total=len(groups), desc="Group Num")):
        files = os.listdir(g+'/testA')
        files.sort()
        # print(g)
        model_name = opt.name
        file_out = g  +f"/outputs_{model_name}/"
        if not os.path.exists(file_out): os.mkdir(file_out)
        for file in files:
            # print(g+"/"+file)
            img = cv2.imread(g+"/testA/"+file)
            frame_height, frame_width, _ = img.shape
            frame_height, frame_width = int(frame_height), int(frame_width)
            transform = get_transform(opt)
            stitched_image = np.zeros_like(img)
            # print(frame_height, frame_width)
            crop_size = min(frame_width, frame_height)
            overlap = 20
            crop_size = min(frame_width, frame_height)
            overlap = 20
            x_starts = list(range(0, frame_width - crop_size, crop_size)) + [frame_width - crop_size]
            y_starts = list(range(0, frame_height - crop_size, crop_size)) + [frame_height - crop_size]
            for file in files:
                # print(g+"/"+file)
                img = cv2.imread(g+"/testA/"+file)
                frame_height, frame_width, _ = img.shape
                frame_height, frame_width = int(frame_height), int(frame_width)
                transform = get_transform(opt)
                stitched_image = np.zeros_like(img)
                # print(frame_height, frame_width)
                crop_size = min(frame_width, frame_height)
                overlap = 20
                x_starts = list(range(0, frame_width - crop_size, crop_size)) + [frame_width - crop_size]
                y_starts = list(range(0, frame_height - crop_size, crop_size)) + [frame_height - crop_size]
                for y in y_starts:
                    for x in x_starts:
                        tile = img[y:y + crop_size, x:x + crop_size]
                        # pil_img = Image.fromarray(tile).resize((256,256))
                        tensor_crop = torch.from_numpy(tile).permute(2, 0, 1).unsqueeze(0).float()
                        # resized_crop = F.interpolate(tensor_crop, size=(256, 256), mode='bilinear', align_corners=False)
                        pil_img = Image.fromarray(tensor_crop.squeeze(0).permute(1, 2, 0).byte().numpy())
                        img_transformed = transform(pil_img).to(model.device)
                        img_transformed = img_transformed.unsqueeze(0)
                        out = model.processAtoB(img_transformed)
                        out = F.interpolate(out, size=(crop_size, crop_size), mode="bilinear", align_corners=False)
                        out_im = tensor2im(out)
                        # print(out_im.dtype)
                        stitched_image[y:y+crop_size, x:x+crop_size] = out_im
                cv2.imwrite(file_out+file, stitched_image)
        

                
