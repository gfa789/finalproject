import cv2
import numpy as np
import os 
from tqdm.auto import tqdm
import torch.nn.functional as F
from PIL import Image
import argparse
import torch
# import tqdm

"""General-purpose test script for image-to-image translation.

Once you have trained your model with train.py, you can use this script to test the model.
It will load a saved model from '--checkpoints_dir' and save the results to '--results_dir'.

It first creates model and dataset given the option. It will hard-code some parameters.
It then runs inference for '--num_test' images and save results to an HTML file.

Example (You need to train models first or download pre-trained models from our website):
    Test a CycleGAN model (both sides):
        python test.py --dataroot ./datasets/maps --name maps_cyclegan --model cycle_gan

    Test a CycleGAN model (one side only):
        python test.py --dataroot datasets/horse2zebra/testA --name horse2zebra_pretrained --model test --no_dropout

    The option '--model test' is used for generating CycleGAN results only for one side.
    This option will automatically set '--dataset_mode single', which only loads the images from one set.
    On the contrary, using '--model cycle_gan' requires loading and generating results in both directions,
    which is sometimes unnecessary. The results will be saved at ./results/.
    Use '--results_dir <directory_path_to_save_result>' to specify the results directory.

    Test a pix2pix model:
        python test.py --dataroot ./datasets/facades --name facades_pix2pix --model pix2pix --direction BtoA

See options/base_options.py and options/test_options.py for more test options.
See training and test tips at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/tips.md
See frequently asked questions at: https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix/blob/master/docs/qa.md
"""
import os
import cv2
# import imageio
import numpy as np
# import copy

import torch
from options.test_options import TestOptions
from data import create_dataset
from models import create_model
# from util.visualizer import save_images
# from util import html
from util.util import tensor2im
from data.george_dataset import load_tiff_image
from PIL import Image, ImageDraw, ImageFont
from data.base_dataset import get_transform
# import torch.nn.functional as F
from tqdm.auto import tqdm

import cv2
# from depth_anything.dpt import DepthAnything
# from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

import torch.nn.functional as F
import torchvision.transforms as transforms
from torchvision.transforms import Compose

if __name__ == '__main__':
    opt = TestOptions().parse()  # get test options
    # hard-code some parameters for test
    opt.num_threads = 0   # test code only supports num_threads = 0
    opt.batch_size = 1    # test code only supports batch_size = 1
    opt.serial_batches = True  # disable data shuffling; comment this line if results on randomly chosen images are needed.
    opt.no_flip = True    # no flip; comment this line if results on flipped images are needed.
    opt.display_id = -1 
    dataset = create_dataset(opt)  # create a dataset given opt.dataset_mode and other options
    model = create_model(opt)      # create a model given opt.model and other options
    model.setup(opt)

    if opt.eval:
        model.eval()
    
    inputdir = f"../SyreaNet/synthesize/evaluate/SAUD/Benchmark/Raw/group_"
    groups = [inputdir + str(x) for x in range(1,6)]

    def randCrop(h, w):
        min_res = min(w-1, h-1)
        crop_size = min(min_res, 800)
        rand_width = np.random.randint(0, w-crop_size+1)
        rand_height = np.random.randint(0, h-crop_size+1)
        # im = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
        return rand_height,rand_width, crop_size

    def cropImage(im, sx, sy, cs):
        return im[sy:sy+cs, sx:sx+cs]

    transform_list =[
        transforms.Resize((256,256)),
        transforms.ToTensor()
    ]
    transform = Compose(transform_list)        
    # DEFINE MODEL

    video_path = "A2"

    def mkdirs(dirs):
        for dir in dirs:
            if not os.path.exists(dir):
                os.mkdir(dir)

    outdir = "video_benchmark"
    video_inputdir = f"{outdir}/{video_path}"
    final_dir = f"{outdir}/outputs"

    mkdirs([outdir, final_dir])

    frame_paths = os.listdir(video_inputdir)
    frame_paths = [f'{video_inputdir}/{x}.png' for x in sorted([int(y[:-4]) for y in frame_paths])]

    def tileModelStitch(input_buffer, transform):
        crop_size = 256
        h, w, _ = input_buffer[0].shape
        stitched_image = np.zeros_like(input_buffer[0])
        x_starts = list(range(0, w - crop_size, crop_size)) + [w - crop_size]
        y_starts = list(range(0, h - crop_size, crop_size)) + [h - crop_size]
        for y in y_starts:
            for x in x_starts:
                imgs = []
                for input in input_buffer:
                    tile = input[y:y + crop_size, x:x + crop_size]
                    pil_img = Image.fromarray(tile)
                    img_transformed = transform(pil_img).to(model.device)
                    img_transformed = img_transformed.unsqueeze(0)
                    imgs.append(img_transformed)
                img_transformed = torch.cat(imgs, dim=1)
                out = model.processAtoB(img_transformed)
                out = tensor2im(out)
                stitched_image[y:y + crop_size, x:x + crop_size] = out
        return stitched_image
    
    def ApplyModel(input_buffer, transform):
        h, w, _ = input_buffer[0].shape
        imgs = []
        for input in input_buffer:
            pil_img = Image.fromarray(input)
            img_transformed = transform(pil_img).to(model.device)
            img_transformed = img_transformed.unsqueeze(0)
            imgs.append(img_transformed)
        img_transformed = torch.cat(imgs, dim=1)
        out = model.processAtoB(img_transformed)
        out = F.interpolate(out, (h, w), mode="bilinear", align_corners=False)
        out = tensor2im(out)
        return out

    rows = []
    buffer = []
    transform = get_transform(opt)
    tile = False
    for i, frame_path in tqdm(enumerate(frame_paths)):
        if i + 3 > len(frame_paths): break
        img = cv2.imread(frame_path)
        buffer.append(img)
        if len(buffer) < 5: continue
        if len(buffer) > 5: buffer.pop(0)
        height,width,_ = img.shape
        if tile:
            output = tileModelStitch(buffer, transform)
        else:
            output = ApplyModel(buffer, transform)
        middle_index = width//2
        middle_row = output[:, middle_index]
        rows.append(middle_row)

    complete_image = np.array(rows)
    # print(np.array(rows).shape)
    # complete_image = np.vstack(rows)
    # print(complete_image.shape)
    # if args.model:
    if tile:
        cv2.imwrite(f"{final_dir}/{video_path}_{opt.name}_{opt.epoch}.png", complete_image)
    else:
        cv2.imwrite(f"{final_dir}/{video_path}_{opt.name}_{opt.epoch}_NOTILE.png", complete_image)

    # else:
        # cv2.imwrite(f"{final_dir}/{video_path}.png", complete_image)
