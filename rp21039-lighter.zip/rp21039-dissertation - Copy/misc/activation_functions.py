import numpy as np
import matplotlib.pyplot as plt

def relu(x):
    return np.maximum(0, x)

def leaky_relu(x, alpha=0.1):
    return np.maximum(alpha * x, x)

def gelu(x):
    return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))

x = np.linspace(-3, 3, 100)

y_relu = relu(x)
y_leaky_relu = leaky_relu(x)
y_gelu = gelu(x)

plt.plot(x, y_relu, label='ReLU = max(0,x)')
plt.plot(x, y_leaky_relu, label='Leaky ReLU = max(0.1x, x)')
plt.plot(x, y_gelu, label='GeLU = xΦ(x)')

plt.xlabel('x')
plt.ylabel('y')
plt.title('Activation Functions')
plt.legend()
plt.show()
