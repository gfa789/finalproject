import cv2
import numpy as np
import os

idxs = [int(x.replace(".png","")) for x in os.listdir("udcp")]


indir = "A2/uwgan"
files = os.listdir(indir)

index = range(0,498)
sorted_files = [f"{indir}/{x}.png" for x in index]

columns = []
firstIm = False
for i, file in enumerate(sorted_files):
    # print(file)
    img = cv2.imread(file)
    if i+1 in idxs:
        if img is not None:
            last_img = np.copy(img)
            firstIm = True
        else:
            if firstIm:
                img = np.copy(last_img)
    else:
        if firstIm:
            img = np.copy(last_img)
    
        # none_start_counter += 1
    if firstIm:
        h,w,_ = img.shape
        middle = w//2
        column = img[:, middle]
        columns.append(column)
        
    

complete = np.array(columns)
print(complete.shape)
cv2.imwrite("temp-uvcfixed.png", complete)