
import os

import numpy as np
from data.base_dataset import BaseDataset, get_transform
from data.image_folder import make_dataset
from PIL import Image
import random
from torchvision.utils import save_image
import torch



def load_tiff_image(tiff_path):
    with Image.open(tiff_path) as img:
        # Initialize a list to hold the numpy arrays of the images
        images = []
        
        # Loop through each frame in the TIFF file
        for i in range(img.n_frames):
            img.seek(i)  # Move to the next frame
            # Convert the image to RGB and then to a numpy array
            frame = np.array(img.convert('RGB'))
            images.append(frame)
            
        # Stack images to have a shape of (5, H, W, 3) assuming 5 sets of 3-channel images
        stacked_images = np.stack(images, axis=0)
    return stacked_images

def stack_2_one(stacked_images):
    trans = stacked_images.transpose(0,3,1,2)
    _, _, height, width = trans.shape
    merge = trans.reshape(-1, height, width)
    merge = merge.transpose(1,2,0)
    return merge


class GeorgeDataset(BaseDataset):
    """
    This dataset class can load unaligned/unpaired datasets.

    It requires two directories to host training images from domain A '/path/to/data/trainA'
    and from domain B '/path/to/data/trainB' respectively.
    You can train the model with the dataset flag '--dataroot /path/to/data'.
    Similarly, you need to prepare two directories:
    '/path/to/data/testA' and '/path/to/data/testB' during test time.
    """

    def __init__(self, opt):
        """Initialize this dataset class.

        Parameters:
            opt (Option class) -- stores all the experiment flags; needs to be a subclass of BaseOptions
        """
        BaseDataset.__init__(self, opt)
        self.dir_A = os.path.join(opt.dataroot, opt.phase + 'A')  # create a path '/path/to/data/trainA'
        self.dir_B = os.path.join(opt.dataroot, opt.phase + 'B')  # create a path '/path/to/data/trainB'

        self.A_paths = sorted(make_dataset(self.dir_A, opt.max_dataset_size))   # load images from '/path/to/data/trainA'
        self.B_paths = sorted(make_dataset(self.dir_B, opt.max_dataset_size))   # load images from '/path/to/data/trainB'
        self.A_size = len(self.A_paths)  # get the size of dataset A
        self.B_size = len(self.B_paths)  # get the size of dataset B
        btoA = self.opt.direction == 'BtoA'
        self.input_nc = self.opt.output_nc if btoA else self.opt.input_nc       # get the number of channels of input image
        self.output_nc = self.opt.input_nc if btoA else self.opt.output_nc      # get the number of channels of output image
        if opt.randcrop: self.params = None  
        else: self.params = {'crop_pos': (0,0)}
        self.transform_A = get_transform(self.opt, params=self.params, grayscale=(self.input_nc == 1))
        self.transform_B = get_transform(self.opt, grayscale=(self.output_nc == 1))
        

    def __getitem__(self, index):
        """Return a data point and its metadata information.

        Parameters:
            index (int)      -- a random integer for data indexing

        Returns a dictionary that contains A, B, A_paths and B_paths
            A (tensor)       -- an image in the input domain
            B (tensor)       -- its corresponding image in the target domain
            A_paths (str)    -- image paths
            B_paths (str)    -- image paths
        """
        A_path = self.A_paths[index % self.A_size]  # make sure index is within then range
        if self.opt.serial_batches:   # make sure index is within then range
            index_B = index % self.B_size
        else:   # randomize the index for domain B to avoid fixed pairs.
            index_B = random.randint(0, self.B_size - 1)
        B_path = self.B_paths[index_B]

        A_img = load_tiff_image(A_path)
        B_img = Image.open(B_path).convert('RGB')

        As = []
        for frame_A in A_img:
            frame_A = Image.fromarray(frame_A.astype('uint8'), 'RGB' )
            A = self.transform_A(frame_A)
            As.append(A)

        A = torch.cat(As, dim=0)
        B = self.transform_B(B_img)

        return {'A': A, 'B': B, 'A_paths': A_path, 'B_paths': B_path}

    def __len__(self):
        """Return the total number of images in the dataset.

        As we have two datasets with potentially different number of images,
        we take a maximum of
        """
        return max(self.A_size, self.B_size)
