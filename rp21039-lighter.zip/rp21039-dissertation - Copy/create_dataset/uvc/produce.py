import json
import os
import glob
import random
# from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
import numpy as np
import argparse
# from util.util import mkdirs
from PIL import Image
import imageio
from itertools import groupby
import torch


import cv2

import torch.nn.functional as F
from torchvision.transforms import Compose

from datetime import datetime

def mkdirs(dirs):
    for dir in dirs:
        if not os.path.exists(dir): os.mkdir(dir)

def anyNotExist(dirs):
    for dir in dirs:
        if not os.path.exists(dir):
            return False
    return True

outdir = "example_dataset"

sections = ["", "trainA", "trainAdepth", "trainB", "trainBdepth", "testA", "testAdepth", 
            "testB", "testBdepth", "valA", "valAdepth", "valB", "valBdepth"]
mkdirs(["data/"])
mkdirs(["data/"+ outdir + '/' + x for x in sections])

# DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# if __name__ == "__main__":
    # DEVICE = 'cpu'
    # encoder = "vitl"
    # depth_anything = DepthAnything.from_pretrained('LiheYoung/depth_anything_{}14'.format(encoder)).to(DEVICE).eval()

    # transform = Compose([
    #     Resize(
    #         width=256,
    #         height=256,
    #         resize_target=False,
    #         keep_aspect_ratio=True,
    #         ensure_multiple_of=14,
    #         resize_method='lower_bound',
    #         image_interpolation_method=cv2.INTER_CUBIC,
    #     ),
    #     NormalizeImage(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    #     PrepareForNet(),
    # ])

dataset_dir = "data/example_dataset/"

labels = [
     "trainA.txt", "trainB.txt", 
          "testA.txt", "testB.txt", "valA.txt", "valB.txt"]

w_border, h_border = 8,6

np.random.seed(8)


def scale(img):
    return (img - np.min(img)) / (np.max(img) - np.min(img))

def randCrop(h, w, frame):
    min_res = min(w-1, h-1)
    crop_size = min(min_res, 800)
    rand_width = np.random.randint(0, w-crop_size+1)
    rand_height = np.random.randint(0, h-crop_size+1)
    im = frame[rand_height:rand_height+crop_size, rand_width:rand_width+crop_size]
    return im 


if __name__ == "__main__":

    #Iterate through train test val txts
    for label in tqdm(labels):
        f = open(dataset_dir + label, "r")
        f = [x.strip().split(',') for x in f]
        sort = sorted(f, key=lambda x: x[2])
        out = label.replace(".txt", "")

        #group by images source i.e. video or NYUD
        for key, group in groupby(sort, key=lambda x: x[2]):
            #If video
            # if "nyu" not in key:
                raw_video = cv2.VideoCapture(key)
                frame_width, frame_height = int(raw_video.get(cv2.CAP_PROP_FRAME_WIDTH)), int(raw_video.get(cv2.CAP_PROP_FRAME_HEIGHT))
                frame_rate = int(raw_video.get(cv2.CAP_PROP_FPS))
                total_frames = int(raw_video.get(cv2.CAP_PROP_FRAME_COUNT))

                #Get image info - i.e. frame number and source file
                group_aslist = list(group)
                idx = [int(x[0]) for x in group_aslist]
                filename = [x[1] for x in group_aslist][0]
                print(len(idx))
                #Iterate through video for respective idxs
                for i in tqdm(idx, desc=f"Processing {key}"):
                        # Create prospective file paths
                        outname_img = dataset_dir + out +'/' + filename + '_' + str(i) + '.png'

                        #If not already processed iterate 
                        if not anyNotExist([outname_img]):

                            #Get frame
                            raw_video.set(cv2.CAP_PROP_POS_FRAMES, i)
                            ret, frame = raw_video.read()
                            if not ret:
                                break

                            #Crop and resize, save as cleaned data
                            im = randCrop(frame_height, frame_width, frame)
                            im = cv2.resize(im, (256,256))
                            cv2.imwrite(outname_img, im)

                            

                raw_video.release()
           