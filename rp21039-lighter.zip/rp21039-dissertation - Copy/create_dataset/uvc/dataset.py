import os
import glob
import random
# from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
import numpy as np
import argparse
from PIL import Image
import imageio
# import h5py

parser = argparse.ArgumentParser()
parser.add_argument("--dir", type=str, default="..c/synthesize/vids/")
parser.add_argument("--subdir", type=str, default="")
parser.add_argument("--spec", default = True, action='store_false')

parser.add_argument("--maxtr", default = 4000, type =int)
parser.add_argument("--outdir", default = "example_dataset", type =str)
args = parser.parse_args()
data_dir = args.dir
spec = args.spec

def mkdirs(dirs):
    for dir in dirs:
        if not os.path.exists(dir): os.mkdir(dir)

sections = ["", "trainA", "trainAdepth", "trainB", "trainBdepth", "testA", "testAdepth", 
            "testB", "testBdepth", "valA", "valAdepth", "valB", "valBdepth"]
mkdirs(["data/"])
mkdirs(["data/"+ args.outdir + '/' + x for x in sections])


# def getFile(path):
#     # with h5py.File(path, 'r') as file:
#     #     return file
#     file = h5py.File(path, 'r')
#     images = np.array(file['images'])
#     images = np.transpose(images, (0, 3, 2, 1))

#     depths = np.array(file['depths'])
#     depths = np.transpose(depths, (0, 2, 1))
#     return images, depths


# vid_links = ['A1','A4', 'A9', 'A13', 'A7', 'canyon1raw', 'correctedraw' #BAD
#             ,'rockgardenraw', 'zhong1raw', 'zhong2raw', 'yt1','yt2','yt3'#BAD
#             ,'HDPC210120', 'HDGH011605', 'HD11404', 'HD11409', 'HD11417' #GOOD
#             , 'HD11414', 'HD11459', 'yt4good', 'yt5good', 'yt6good'] #GOOD

if __name__ == "__main__":
    vid_links = ['zhong1raw', 'zhong2raw', 'yt8bad', 'yt9bad', 'yt7bad',
                'A1','A3','A9','A19','canyon1raw', 'correctedraw','Original11419',
                'rockgardenraw', 'yt1','yt2',
                'yt4good','yt6good','HD11461good', 'HDPC210120', 'yt9good']
    data_links = [data_dir + x +'.mp4' for x in vid_links]

    print(data_links[:5])

    bad_links, good_links = vid_links[:15], vid_links[15:]
    bad_data, good_data = data_links[:15], data_links[15:]

    INTRO_LENGTH = 200
    OUTRO_LENGTH = 200

    good_data.sort()
    bad_data.sort()
    good_links.sort()
    bad_links.sort()
    np.random.seed(8)
    dir_links_y = good_data
    Y = []
    for l, link in enumerate(dir_links_y):
        reader = imageio.get_reader(link)
        meta_data = reader.get_meta_data()
        # frame_count = meta_data['nframes']
        frame_count = int(np.floor(meta_data['fps'] * (meta_data['duration']-1)))
        frames = np.arange(0,frame_count, dtype=np.uint32)
        # link_nomp4 = link.replace(".mp4", "")
        allfiles = [(x, good_links[l], link) for x in frames if x >= INTRO_LENGTH or x <= frame_count - OUTRO_LENGTH]
        for i in allfiles:
            Y.append(i)

    X = []
    dir_links_x = bad_data
    for l, link in enumerate(dir_links_x):
        reader = imageio.get_reader(link)
        meta_data = reader.get_meta_data()
        # frame_count = meta_data['nframes']
        frame_count = int(np.floor(meta_data['fps'] * (meta_data['duration']-1)))
        frames = np.arange(0,frame_count, dtype=np.uint32)
        # link_nomp4 = link.replace(".mp4", "")
        allfiles = [(x, bad_links[l], link) for x in frames if x >= INTRO_LENGTH or x <= frame_count - OUTRO_LENGTH]
        for i in allfiles:
            X.append(i)
    # Split the data
    X_indices = np.arange(len(X))
    np.random.shuffle(X_indices)
    X = [X[j] for j in X_indices]

    
    y_indices = np.arange(len(Y))
    np.random.shuffle(y_indices)
    Y = [Y[y] for y in y_indices]

    train_ratio = 0.7
    validation_ratio = 0.15
    test_ratio = 0.15

    
    print(f"length of X: {len(X)}, length of y: {len(Y)}")

    np.random.seed(42)
    X_trunc = np.array(X)
    y_trunc = np.array(Y)
    if len(X) > len(Y):
        X_indices = np.random.choice(len(X), size=len(y), replace=False)
        X_trunc = np.array([X[i] for i in X_indices])
    elif len(X) <= len(Y):
        y_indices = np.random.choice(len(Y), size=len(X), replace=False)
        y_trunc = np.array([Y[i] for i in y_indices])

    total = X_trunc.shape[0]
    train_end = int(total * train_ratio)
    validation_end = int(train_end + total * validation_ratio)

    X_train, X_val, X_test = X_trunc[:train_end], X_trunc[train_end:validation_end], X_trunc[validation_end:]
    y_train, y_val, y_test = y_trunc[:train_end], y_trunc[train_end:validation_end], y_trunc[validation_end:]

    X_train, X_val, X_test = X_train[:20000], X_val[:200], X_test[:200]
    y_train, y_val, y_test = y_train[:20000], y_val[:200], y_test[:200]
    print(f"Train size: {len(X_train)} | Test size: {len(X_test)} | Val size: {len(X_val)}")

    def write(set, label):
        f = open(f"data/{args.outdir + '/' + label}.txt", "w")
        for num, file, vid in set:
            f.write(f"{num},{file},{vid}\n")

    sets = [X_train, y_train, X_test, y_test, X_val, y_val]
    labels = ["trainA", "trainB", "testA", "testB", "valA", "valB"]

    for set, label in zip(sets,labels):
        write(set, label)