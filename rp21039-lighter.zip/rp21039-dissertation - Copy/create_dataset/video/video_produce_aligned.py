import json
import os
import glob
import random
# from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
import numpy as np
import argparse
# from util.util import mkdirs
from PIL import Image
import imageio
from itertools import groupby
import torch
import h5py


import cv2
from depth_anything.dpt import DepthAnything
from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

import torch.nn.functional as F
from torchvision.transforms import Compose

from skimage.restoration import denoise_tv_chambolle, estimate_sigma
from datetime import datetime

def mkdirs(dirs):
    for dir in dirs:
        if not os.path.exists(dir): os.mkdir(dir)

def anyNotExist(dirs):
    for dir in dirs:
        if not os.path.exists(dir):
            return False
    return True

outdir = "vid_loss_dataset"

sections = ["", "train", "traindepth", "test", "testdepth", 
            "val", "valdepth"]
mkdirs(["sets/"])
mkdirs(["sets/"+ outdir + '/' + x for x in sections])

# DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
if __name__ == "__main__":
    DEVICE = 'cpu'
    encoder = "vitl"
    depth_anything = DepthAnything.from_pretrained('LiheYoung/depth_anything_{}14'.format(encoder)).to(DEVICE).eval()

    transform = Compose([
        Resize(
            width=256,
            height=256,
            resize_target=False,
            keep_aspect_ratio=True,
            ensure_multiple_of=14,
            resize_method='lower_bound',
            image_interpolation_method=cv2.INTER_CUBIC,
        ),
        NormalizeImage(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        PrepareForNet(),
    ])

def getFile(path):
    # with h5py.File(path, 'r') as file:
    #     return file
    file = h5py.File(path, 'r')
    images = np.array(file['images'])
    images = np.transpose(images, (0, 3, 2, 1))

    depths = np.array(file['depths'])
    depths = np.transpose(depths, (0, 2, 1))
    return images, depths

dataset_dir = "sets/vid_loss_dataset/"

labels = [
    "train.txt", 
          "test.txt", "val.txt"]

w_border, h_border = 8,6

np.random.seed(8)


def scale(img):
    return (img - np.min(img)) / (np.max(img) - np.min(img))

def estimate_backscattering(depths, B_inf, beta_B, J_prime, beta_D_prime):
    val = (B_inf * (1 - np.exp(-1 * beta_B * depths))) + (J_prime * np.exp(-1 * beta_D_prime * depths))
    return val

def calculate_beta_D(depths, a, b, c, d):
    return (a * np.exp(b * depths)) + (c * np.exp(d * depths))

def degrade_image(img, depth, B, beta_D, wbalance):
    img = scale(img / np.expand_dims(wbalance, (0, 1)))
    t = np.exp(-beta_D * np.expand_dims(depth, axis=2))
    degrade = img * t + B
    degrade = np.maximum(0.0, np.minimum(1.0, degrade))
    return degrade

def pipeline(depth, im, coefs):
    # depth = cv2.imread(outname_depth, cv2.IMREAD_GRAYSCALE)
    depth = cv2.GaussianBlur(depth, (7, 7), 5) * 1.0
    depth = ((depth - np.min(depth)) / (np.max(depth) - np.min(depth))).astype(np.float32)
    depth = 1 - depth
    depth = 10. * depth + 2.
    im = im * 255
    # get coefficients
    Bcoefs_r, Bcoefs_g, Bcoefs_b = np.array(coefs["Bcoefs_r"]), np.array(coefs["Bcoefs_g"]), np.array(coefs["Bcoefs_b"])
    Dcoefs_r, Dcoefs_g, Dcoefs_b = np.array(coefs["Dcoefs_r"]), np.array(coefs["Dcoefs_g"]), np.array(coefs["Dcoefs_b"])
    wbalance = np.array(coefs['wbalance'])
    # estimate backscattering
    Br = estimate_backscattering(depth, *Bcoefs_r)
    Bg = estimate_backscattering(depth, *Bcoefs_g)
    Bb = estimate_backscattering(depth, *Bcoefs_b)
    B = np.stack([Br, Bg, Bb], axis=2)
    # estimate direct transmission
    beta_D_r = calculate_beta_D(depth, *Dcoefs_r) * 0.5
    beta_D_g = calculate_beta_D(depth, *Dcoefs_g) * 0.5
    beta_D_b = calculate_beta_D(depth, *Dcoefs_b) * 0.5
    beta_D = np.stack([beta_D_r, beta_D_g, beta_D_b], axis=2)
    # degrade images
    degraded = degrade_image(im, depth, B, beta_D, wbalance)
    sigma_est = estimate_sigma(degraded, average_sigmas=True, channel_axis=-1) / 10.0
    degraded = denoise_tv_chambolle(degraded, sigma_est)
    return degraded

def getDepth(input):
    image = transform({'image': input})['image']
    image = torch.from_numpy(image).unsqueeze(0).to(DEVICE)
    h, w = 256, 256
    with torch.no_grad():
        depth = depth_anything(image)
    depth = F.interpolate(depth[None], (h, w), mode='bilinear', align_corners=False)[0, 0]
    depth = (depth - depth.min()) / (depth.max() - depth.min()) 
    depth = depth.cpu().numpy().astype(np.float32)
    depth = 255 * depth
    return depth

def randCrop(start_x, end_x, start_y, end_y, frame):
    im = frame[start_y:end_y, start_x:end_x]
    return im 

def getCropCoords(h,w):
    min_res = min(w-1, h-1)
    crop_size = min(min_res, 800)
    start_x = np.random.randint(0, w-crop_size+1)
    start_y = np.random.randint(0, h-crop_size+1)
    end_x = start_x+crop_size
    end_y = start_y+crop_size
    return start_x, end_x, start_y, end_y



if __name__ == "__main__":

    coefs = json.load(open('coeffs.json', 'r'))

    #Iterate through train test val txts
    for label in tqdm(labels):
        f = open(dataset_dir + label, "r")
        f = [x.strip().split(',') for x in f]
        sort = sorted(f, key=lambda x: x[2])
        out = label.replace(".txt", "")

        #group by images source i.e. video or NYUD
        for key, group in groupby(sort, key=lambda x: x[2]):
            #If video
            raw_video = cv2.VideoCapture(key)
            frame_width, frame_height = int(raw_video.get(cv2.CAP_PROP_FRAME_WIDTH)), int(raw_video.get(cv2.CAP_PROP_FRAME_HEIGHT))
            frame_rate = int(raw_video.get(cv2.CAP_PROP_FPS))
            total_frames = int(raw_video.get(cv2.CAP_PROP_FRAME_COUNT))

            #Get image info - i.e. frame number and source file
            group_aslist = list(group)
            idx = [int(x[0]) for x in group_aslist]
            filename = [x[1] for x in group_aslist][0]

            #Iterate through video for respective idxs
            for i in tqdm(idx, desc=f"Processing {key}"):
                    #get crop coords for each video clip
                    
                    start_x, end_x, start_y, end_y = getCropCoords(frame_height, frame_width)

                    #Get synthesis coefficients for each video clip
                    k = random.sample(list(coefs.keys()), 1)[0]
                    # Create prospective file paths
                    outname_img = dataset_dir + out +'/' + filename + '_' + str(i) + '.png'
                    outname_depth = dataset_dir + out + 'depth/' + filename + '_' + str(i) + '.png'

                    #If not already processed iterate 
                    a_imgs = []
                    b_imgs = []
                    a_d_imgs = []
                    b_d_imgs = []
                    if not anyNotExist([outname_img, outname_depth]):
                        for j in range(5):

                                #Get frame
                                raw_video.set(cv2.CAP_PROP_POS_FRAMES, i+(j*8))
                                ret, frame = raw_video.read()
                                if not ret:
                                    break

                                #Crop and resize, save as cleaned data
                                im = randCrop(start_x, end_x, start_y, end_y, frame)
                                im = cv2.resize(im, (256,256))
                                a_imgs.append(im)
                                # cv2.imwrite(outname_img, im)

                                #Get depth of clean data
                                im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB) / 255.0
                                depth = getDepth(im)
                                a_d_imgs.append(depth)
                                # cv2.imwrite(outname_depth, depth)
        
                                #Create synthetic image
                                degraded = pipeline(depth, im, coefs[k])
                                im = Image.fromarray((np.clip(np.round(degraded * 255.0), 0, 255)).astype(np.uint8))
                                im = np.array(im)
                                im_bgr = cv2.cvtColor(im, cv2.COLOR_RGB2BGR)
                                # im.save(outname_synth, format='png')
                                b_imgs.append(im_bgr)

                                #Get depth of synthetic image
                                synth_image = np.copy(im_bgr) / 255.
                                # synth_image = cv2.cvtColor(synth_image, cv2.COLOR_BGR2RGB) / 255.0
                                synth_depth = getDepth(synth_image)
                                b_d_imgs.append(synth_depth)
                                # cv2.imwrite(outname_syndepth, synth_depth)
                        a_stack = np.vstack(a_imgs)
                        b_stack = np.vstack(b_imgs)

                        a_d_stack = np.vstack(a_d_imgs)
                        b_d_stack = np.vstack(b_d_imgs)

                        ab_stack = np.hstack([a_stack, b_stack])
                        ab_d_stack = np.hstack([a_d_stack, b_d_stack])

                        cv2.imwrite(outname_img, ab_stack)
                        cv2.imwrite(outname_depth, ab_d_stack)
            raw_video.release()
            