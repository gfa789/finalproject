import os
import glob
# from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
import numpy as np
import argparse
from PIL import Image
import imageio
import h5py

parser = argparse.ArgumentParser()
parser.add_argument("--dir", type=str, default="./vids/")
parser.add_argument("--subdir", type=str, default="")
parser.add_argument("--spec", default = True, action='store_false')

parser.add_argument("--maxtr", default = 4000, type =int)
parser.add_argument("--outdir", default = "example_video_dataset", type =str)
args = parser.parse_args()
data_dir = args.dir
spec = args.spec

def mkdirs(dirs):
    for dir in dirs:
        if not os.path.exists(dir): os.mkdir(dir)

sections = ["", "train", "traindepth", "test", "testdepth", 
         "val", "valdepth"]
mkdirs(["sets/"])
mkdirs(["sets/"+ args.outdir + '/' + x for x in sections])

if __name__ == "__main__":
    vid_links = ['zhong1raw', 'zhong2raw', 'yt8bad', 'yt9bad', 'yt7bad',
                'A1','A3','A9','A19','canyon1raw', 'correctedraw','Original11419',
                'rockgardenraw', 'yt1','yt2',
                'yt4good','yt6good','HD11461good', 'HDPC210120', 'yt9good']
    data_links = ['./vids/'+x+'.mp4' for x in vid_links]

    bad_links, good_links = vid_links[:15], vid_links[15:]
    bad_data, good_data = data_links[:15], data_links[15:]

    INTRO_LENGTH = 1000
    OUTRO_LENGTH = 1000

    good_data.sort()
    bad_data.sort()
    good_links.sort()
    bad_links.sort()
    np.random.seed(8)
    dir_links_y = good_data
    dataset = []
    for l, link in enumerate(dir_links_y):
        reader = imageio.get_reader(link)
        meta_data = reader.get_meta_data()
        # frame_count = meta_data['nframes']
        frame_count = int(np.floor(meta_data['fps'] * (meta_data['duration']-1)))
        frames = np.arange(0,frame_count, dtype=np.uint32)
        # link_nomp4 = link.replace(".mp4", "")
        allfiles = [(x, good_links[l], link) for x in frames if x >= INTRO_LENGTH or x <= frame_count - OUTRO_LENGTH]
        for i, tup in enumerate(allfiles):
            if good_links[l] == 'yt6good' and i % 20 != 0: continue
            dataset.append(tup)

    # Split the data
    train_ratio = 0.8
    validation_ratio = 0.1
    test_ratio = 0.1

    # for nyu in nyu_filenames:
    #     dataset.append(nyu)


    print(f"length of dataset: {len(dataset)}")

    indices = np.arange(len(dataset))
    np.random.shuffle(indices)

    dataset = [dataset[i] for i in indices]

    total = len(dataset)
    train_end = int(total * train_ratio)
    validation_end = int(train_end + total * validation_ratio)

    train, val, test = dataset[:train_end], dataset[train_end:validation_end], dataset[validation_end:]
    train, val, test, = train[:1000], test[:50], val[:50]

    print(f"Train size: {len(train)} | Test size: {len(test)} | Val size: {len(val)}")

    def write(set, label):
        f = open(f"sets/{args.outdir + '/' + label}.txt", "w")
        for num, file, vid in set:
            f.write(f"{num},{file},{vid}\n")

    sets = [train, test, val]
    labels = ["train", "test", "val"]

    for set, label in zip(sets,labels):
        write(set, label)