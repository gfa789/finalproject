import os
import glob
# from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
import numpy as np
import argparse
# from util.util import mkdirs
from PIL import Image
import imageio
from itertools import groupby
import torch


import cv2
from depth_anything.dpt import DepthAnything
from depth_anything.util.transform import Resize, NormalizeImage, PrepareForNet

import torch.nn.functional as F
from torchvision.transforms import Compose
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
encoder = "vitl"
depth_anything = DepthAnything.from_pretrained('LiheYoung/depth_anything_{}14'.format(encoder)).to(DEVICE).eval()

total_params = sum(param.numel() for param in depth_anything.parameters())
print('Total parameters: {:.2f}M'.format(total_params / 1e6))

transform = Compose([
    Resize(
        width=256,
        height=256,
        resize_target=False,
        keep_aspect_ratio=True,
        ensure_multiple_of=14,
        resize_method='lower_bound',
        image_interpolation_method=cv2.INTER_CUBIC,
    ),
    NormalizeImage(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    PrepareForNet(),
])



# labels = [ 
#      "trainA","good_uw", "valA", "valB", 
#           "testA", "testB"]
# for label in labels:
#      labeldir = args.outdir + '/' + label
#      if not os.path.exists(labeldir): os.mkdir(labeldir)
# labels = [args.outdir + '/' + x + '.txt' for x in labels]
labels = ["good_uw.txt"]
if not os.path.exists("good_uw"): os.mkdir("good_uw")
if not os.path.exists("good_uw/depth"): os.mkdir("good_uw/depth")
if not os.path.exists("good_uw/img"): os.mkdir("good_uw/img")

for label in tqdm(labels):
    f = open(label, "r")
    f = [x.strip().split(',') for x in f]
    sort = sorted(f, key=lambda x: x[2])
    out = label.replace(".txt", "/")
    for key, group in groupby(sort, key=lambda x: x[2]):
        # reader = imageio.get_reader(key)
        raw_video = cv2.VideoCapture(key)
        frame_width, frame_height = int(raw_video.get(cv2.CAP_PROP_FRAME_WIDTH)), int(raw_video.get(cv2.CAP_PROP_FRAME_HEIGHT))
        frame_rate = int(raw_video.get(cv2.CAP_PROP_FPS))
        total_frames = int(raw_video.get(cv2.CAP_PROP_FRAME_COUNT))

        group_aslist = list(group)
        idx = [int(x[0]) for x in group_aslist]
        filename = [x[1] for x in group_aslist][0]
        # for i, frame in enumerate(reader):
        #     if i in idx:
        for i in tqdm(idx, desc=f"Processing {key.replace('../../pytorch-CycleGAN-and-pix2pix/', '')}"):
                # print(key, i, len(reader))
                # if True: outname = out + filename + '_' + str(i) + '.png'
                # else: outname = out + "depth"+ str(i) + filename + ".png"
                outname_img = out + 'img/' + filename + '_' + str(i) + '.png'
                outname_depth = out + 'depth/' + filename + '_' + str(i) + '.png'
                if not os.path.exists(outname_img) or not os.path.exists(outname_depth):
                    raw_video.set(cv2.CAP_PROP_POS_FRAMES, i)
                    ret, frame = raw_video.read()
                    if not ret:
                        break
                    im = cv2.resize(frame, (256,256))
                    cv2.imwrite(outname_img, im)
                    im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB) / 255.0
                    # im_resized = cv2.resize()
                    if True:
                        image = transform({'image': im})['image']
                        # print(image.shape)
                        image = torch.from_numpy(image).unsqueeze(0).to(DEVICE)
                        h, w = 256, 256
                        with torch.no_grad():
                            depth = depth_anything(image)
                        depth = F.interpolate(depth[None], (h, w), mode='bilinear', align_corners=False)[0, 0]
                        depth = (depth - depth.min()) / (depth.max() - depth.min()) 
                        # dp = ((dp - np.min(dp)) / (np.max(dp) - np.min(dp))).astype(np.float32)
                        
                        depth = depth.cpu().numpy().astype(np.float32)
                        # depth = cv2.normalize(depth, None, 0 , 1, cv2.NORM_MINMAX)
                        # depth = depth * 10. + 2.
                        depth = 255 * depth
                        # depth = np.repeat(depth[..., np.newaxis], 3, axis=-1)

                        # rgba_array = np.dstack((image_resized, depth))
                        cv2.imwrite(outname_depth, depth)
                        # imageio.imwrite(outname[:-4] + 'rgb.png', image_resized)
                        # imageio.imwrite(outname, rgba_array)
                        # imageio.imwrite(out + "depth"+ str(i) + filename + ".png", image_rgba)
        raw_video.release()
                
