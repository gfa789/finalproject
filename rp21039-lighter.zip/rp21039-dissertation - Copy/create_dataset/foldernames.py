import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--file", default="separated")
args = parser.parse_args()


f = open(f"sets/{args.file}/{args.file}.txt", "w")

files = os.listdir(f"sets/{args.file}/trainA")

for file in files:
    f.write(file + '\n')